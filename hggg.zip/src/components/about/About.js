import React from 'react'

const About = () => {
  return (
    <div className='container'>About</div>
  )
}

export default About