import React from 'react'
import './home.css'

const Home = () => {
  return (
    <>
    <div className="home_bg" ></div>
    </>
  )
}

export default Home