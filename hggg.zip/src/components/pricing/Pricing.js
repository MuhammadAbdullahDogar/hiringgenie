import React from 'react'

const Pricing = () => {
  return (
    <div className='container'>Pricing</div>
  )
}

export default Pricing