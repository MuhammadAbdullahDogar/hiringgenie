import React from 'react'

const Faqs = () => {
  return (
    <div className='container'>Faqs</div>
  )
}

export default Faqs