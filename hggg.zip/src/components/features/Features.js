import React from 'react'

const Features = () => {
  return (
    <div className='container'>Features</div>
  )
}

export default Features