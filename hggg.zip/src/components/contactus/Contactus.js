import React from 'react'

const Contactus = () => {
  return (
    <div className='container'>Contactus</div>
  )
}

export default Contactus